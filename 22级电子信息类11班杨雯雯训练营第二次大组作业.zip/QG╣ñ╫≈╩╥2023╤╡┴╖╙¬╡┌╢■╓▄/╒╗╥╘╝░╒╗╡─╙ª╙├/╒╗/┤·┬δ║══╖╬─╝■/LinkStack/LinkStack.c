#include "LinkStack.h" 
//��ջ

//��ʼ��ջ
Status initLStack(LinkStack *s){
	printf("�������ʼ���");
	ElemType data=0;
	scanf_s("%d", &data);
	if (!pushLStack(s, data)) {
		return ERROR;
	}
	else {
		return SUCCESS;
	}
}

//�ж�ջ�Ƿ�Ϊ��
Status isEmptyLStack(LinkStack *s){
	if (s->top == NULL) {
		return SUCCESS;
	}
	else { 
		return ERROR; 
	}
}

//�õ�ջ��Ԫ��
Status getTopLStack(LinkStack *s,ElemType *e){
	if (s->top == NULL) {
		return ERROR;
	}
	else {
		*e = (s->top)->data;
		return SUCCESS;
	}
}

//���ջ
Status clearLStack(LinkStack *s){
	destroyLStack(s);
	return SUCCESS;
}

//����ջ
Status destroyLStack(LinkStack *s){
	if (s->top == NULL) {
		return ERROR;
	}
	else {
		ElemType data=0;
		while (s->top != NULL) {
				popLStack((s), &data);
		}
		return SUCCESS;
	}
}

//���ջ����
Status LStackLength(LinkStack *s,int *length){
	if (isEmptyLStack(s)) {//ջΪ���ж�
		return ERROR;
	}
	else {
		ElemType i = 1;
		for (LinkStackPtr pnode = s->top; pnode->next != NULL; i++) {
			pnode = pnode->next;
		}
		*length = i;
	}return SUCCESS;
}

//��ջ
Status pushLStack(LinkStack *s,ElemType data){
	LinkStackPtr temp = (LinkStackPtr)malloc(sizeof(StackNode));
	if (temp == NULL) {
		return ERROR;
	}
	else {
		temp->data = data;
		temp->next = s->top;
		s->top = temp;
		(s->count)++;
	}
	return SUCCESS;
}

//��ջ
Status popLStack(LinkStack *s,ElemType *data){
	if (isEmptyLStack(s)) {
		return ERROR;
	}
	else {
		*data = (s->top)->data;
		LinkStackPtr pnode = s->top;
		s->top = (s->top)->next;
		free(pnode);
		(s->count)--;
	}return SUCCESS;
}

void show(void) {
	printf("*****************************************\n");
	printf("*             1.��ʼ��ջ                *\n");
	printf("*             2.����ջ                  *\n");
	printf("*             3.��ջ��ѹ������          *\n");
	printf("*             4.����ջ������            *\n");
	printf("*             5.�鿴��ʱջ������        *\n");
	printf("*             6.���ջ����              *\n");
	printf("*             7.�Ƿ�Ϊ��ջ              *\n");
	printf("*             8.�˳�ϵͳ                *\n");
	printf("*****************************************\n");
}